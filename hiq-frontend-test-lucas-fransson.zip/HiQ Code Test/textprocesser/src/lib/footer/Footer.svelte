<footer class="absolute bottom-0 w-full flex flex-col justify-center items-center p-10 bg-zinc-900">
    <p class="text-white text-lg">Made by Lucas Fransson for HiQ</p>
</footer>