<script context="module">
	export const prerender = true;
</script>

<script>
	let files;

	function isolateMostCommonWord(str) {
		let words = str.match(/\w+/g);
  		console.log(words);

  		let occurances = {};

  		for (let word of words) {
    		if (occurances[word]) {
      			occurances[word]++;
    		} else {
      			occurances[word] = 1;
    		}
  		}
  

  		console.log(occurances);

  		let max = 0;
  		let mostRepeatedWord = '';
		let processedString = '';

  		for (let word of words) {
    		if (occurances[word] > max) {
      			max = occurances[word];
      			mostRepeatedWord = word;
				processedString = str.replaceAll(mostRepeatedWord, "foo" + mostRepeatedWord + "bar");
    		}
  		}

  		return processedString;
	}
</script>

<svelte:head>
	<title>Text Processer</title>
	<meta name="description" content="Textprocesser" />
</svelte:head>

<main class="flex flex-col content-center items-center flex-1">
	<div>
		<h1 class="text-3xl font-bold p-6">
			Welcome to the Textprocesser!
		</h1>
		<p class="text-lg p-6">Here you can upload a textfile. The Textprocesser will then find the most common word in the text and surround it with the words <b>"foo"</b> and <b>"bar"</b>.</p>
	</div>
	<div>
		<div class="p-2">
			<label class="text-base font-bold" for="file-input">Upload a textfile:</label>
		</div>
		<div class="p-2">
			<input class="text-base" type="file" id="file-input" bind:files>
		</div>
	</div>

	
	{#if files}
		<div>
			{#each Array.from(files) as file}
  				<p class="font-bold">Filename: {file.name}</p>
  				{#await file.text() then text}
    				<p class="text-lg">{isolateMostCommonWord(text)}</p>
  				{/await}
			{/each}
		</div>
	{/if}
</main>