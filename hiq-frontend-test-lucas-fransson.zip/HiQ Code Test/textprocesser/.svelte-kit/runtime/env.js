let prerendering = false;

/** @param {boolean} value */
function set_prerendering(value) {
	prerendering = value;
}

export { prerendering, set_prerendering };
