// this file is generated — do not edit it
/** @type {import('$env/static/private').ALLUSERSPROFILE} */
export const ALLUSERSPROFILE = "C:\\ProgramData";

/** @type {import('$env/static/private').APPDATA} */
export const APPDATA = "C:\\Users\\lucas\\AppData\\Roaming";

/** @type {import('$env/static/private').CHROME_CRASHPAD_PIPE_NAME} */
export const CHROME_CRASHPAD_PIPE_NAME = "\\\\.\\pipe\\crashpad_10876_YGVZFWMOZEKUBATB";

/** @type {import('$env/static/private').COLOR} */
export const COLOR = "1";

/** @type {import('$env/static/private').COLORTERM} */
export const COLORTERM = "truecolor";

/** @type {import('$env/static/private').CommonProgramFiles} */
export const CommonProgramFiles = "C:\\Program Files\\Common Files";

/** @type {import('$env/static/private').CommonProgramW6432} */
export const CommonProgramW6432 = "C:\\Program Files\\Common Files";

/** @type {import('$env/static/private').COMPUTERNAME} */
export const COMPUTERNAME = "LUCASST";

/** @type {import('$env/static/private').ComSpec} */
export const ComSpec = "C:\\windows\\system32\\cmd.exe";

/** @type {import('$env/static/private').DriverData} */
export const DriverData = "C:\\Windows\\System32\\Drivers\\DriverData";

/** @type {import('$env/static/private').EDITOR} */
export const EDITOR = "notepad.exe";

/** @type {import('$env/static/private').FPS_BROWSER_APP_PROFILE_STRING} */
export const FPS_BROWSER_APP_PROFILE_STRING = "Internet Explorer";

/** @type {import('$env/static/private').FPS_BROWSER_USER_PROFILE_STRING} */
export const FPS_BROWSER_USER_PROFILE_STRING = "Default";

/** @type {import('$env/static/private').GIT_ASKPASS} */
export const GIT_ASKPASS = "c:\\Users\\lucas\\AppData\\Local\\Programs\\Microsoft VS Code\\resources\\app\\extensions\\git\\dist\\askpass.sh";

/** @type {import('$env/static/private').HOME} */
export const HOME = "C:\\Users\\lucas";

/** @type {import('$env/static/private').HOMEDRIVE} */
export const HOMEDRIVE = "C:";

/** @type {import('$env/static/private').HOMEPATH} */
export const HOMEPATH = "\\Users\\lucas";

/** @type {import('$env/static/private').INIT_CWD} */
export const INIT_CWD = "C:\\Users\\lucas\\Documents\\HiQ Code Test\\textprocesser";

/** @type {import('$env/static/private').LANG} */
export const LANG = "en_US.UTF-8";

/** @type {import('$env/static/private').LOCALAPPDATA} */
export const LOCALAPPDATA = "C:\\Users\\lucas\\AppData\\Local";

/** @type {import('$env/static/private').LOGONSERVER} */
export const LOGONSERVER = "\\\\LUCASST";

/** @type {import('$env/static/private').NODE} */
export const NODE = "C:\\Program Files\\nodejs\\node.exe";

/** @type {import('$env/static/private').NODE_EXE} */
export const NODE_EXE = "C:\\Program Files\\nodejs\\\\node.exe";

/** @type {import('$env/static/private').NPM_CLI_JS} */
export const NPM_CLI_JS = "C:\\Program Files\\nodejs\\\\node_modules\\npm\\bin\\npm-cli.js";

/** @type {import('$env/static/private').npm_command} */
export const npm_command = "run-script";

/** @type {import('$env/static/private').npm_config_cache} */
export const npm_config_cache = "C:\\Users\\lucas\\AppData\\Local\\npm-cache";

/** @type {import('$env/static/private').npm_config_engine_strict} */
export const npm_config_engine_strict = "true";

/** @type {import('$env/static/private').npm_config_globalconfig} */
export const npm_config_globalconfig = "C:\\Users\\lucas\\AppData\\Roaming\\npm\\etc\\npmrc";

/** @type {import('$env/static/private').npm_config_global_prefix} */
export const npm_config_global_prefix = "C:\\Users\\lucas\\AppData\\Roaming\\npm";

/** @type {import('$env/static/private').npm_config_init_module} */
export const npm_config_init_module = "C:\\Users\\lucas\\.npm-init.js";

/** @type {import('$env/static/private').npm_config_local_prefix} */
export const npm_config_local_prefix = "C:\\Users\\lucas\\Documents\\HiQ Code Test\\textprocesser";

/** @type {import('$env/static/private').npm_config_metrics_registry} */
export const npm_config_metrics_registry = "https://registry.npmjs.org/";

/** @type {import('$env/static/private').npm_config_node_gyp} */
export const npm_config_node_gyp = "C:\\Program Files\\nodejs\\node_modules\\npm\\node_modules\\node-gyp\\bin\\node-gyp.js";

/** @type {import('$env/static/private').npm_config_noproxy} */
export const npm_config_noproxy = "";

/** @type {import('$env/static/private').npm_config_prefix} */
export const npm_config_prefix = "C:\\Users\\lucas\\AppData\\Roaming\\npm";

/** @type {import('$env/static/private').npm_config_userconfig} */
export const npm_config_userconfig = "C:\\Users\\lucas\\.npmrc";

/** @type {import('$env/static/private').npm_config_user_agent} */
export const npm_config_user_agent = "npm/8.3.1 node/v16.14.0 win32 x64 workspaces/false";

/** @type {import('$env/static/private').npm_execpath} */
export const npm_execpath = "C:\\Program Files\\nodejs\\node_modules\\npm\\bin\\npm-cli.js";

/** @type {import('$env/static/private').npm_lifecycle_event} */
export const npm_lifecycle_event = "dev";

/** @type {import('$env/static/private').npm_lifecycle_script} */
export const npm_lifecycle_script = "vite dev";

/** @type {import('$env/static/private').npm_node_execpath} */
export const npm_node_execpath = "C:\\Program Files\\nodejs\\node.exe";

/** @type {import('$env/static/private').npm_package_json} */
export const npm_package_json = "C:\\Users\\lucas\\Documents\\HiQ Code Test\\textprocesser\\package.json";

/** @type {import('$env/static/private').npm_package_name} */
export const npm_package_name = "textprocesser";

/** @type {import('$env/static/private').npm_package_version} */
export const npm_package_version = "0.0.1";

/** @type {import('$env/static/private').NPM_PREFIX_NPM_CLI_JS} */
export const NPM_PREFIX_NPM_CLI_JS = "C:\\Users\\lucas\\AppData\\Roaming\\npm\\node_modules\\npm\\bin\\npm-cli.js";

/** @type {import('$env/static/private').NUMBER_OF_PROCESSORS} */
export const NUMBER_OF_PROCESSORS = "12";

/** @type {import('$env/static/private').OneDrive} */
export const OneDrive = "C:\\Users\\lucas\\OneDrive";

/** @type {import('$env/static/private').ORIGINAL_XDG_CURRENT_DESKTOP} */
export const ORIGINAL_XDG_CURRENT_DESKTOP = "undefined";

/** @type {import('$env/static/private').OS} */
export const OS = "Windows_NT";

/** @type {import('$env/static/private').Path} */
export const Path = "C:\\Users\\lucas\\Documents\\HiQ Code Test\\textprocesser\\node_modules\\.bin;C:\\Users\\lucas\\Documents\\HiQ Code Test\\node_modules\\.bin;C:\\Users\\lucas\\Documents\\node_modules\\.bin;C:\\Users\\lucas\\node_modules\\.bin;C:\\Users\\node_modules\\.bin;C:\\node_modules\\.bin;C:\\Program Files\\nodejs\\node_modules\\npm\\node_modules\\@npmcli\\run-script\\lib\\node-gyp-bin;C:\\windows\\system32;C:\\windows;C:\\windows\\System32\\Wbem;C:\\windows\\System32\\WindowsPowerShell\\v1.0\\;C:\\windows\\System32\\OpenSSH\\;C:\\Program Files (x86)\\NVIDIA Corporation\\PhysX\\Common;C:\\Program Files\\nodejs\\;C:\\Program Files\\Git\\cmd;C:\\Program Files\\dotnet\\;C:\\Users\\lucas\\AppData\\Local\\Microsoft\\WindowsApps;;C:\\Users\\lucas\\AppData\\Local\\Programs\\Microsoft VS Code\\bin;C:\\Users\\lucas\\AppData\\Roaming\\npm";

/** @type {import('$env/static/private').PATHEXT} */
export const PATHEXT = ".COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.CPL";

/** @type {import('$env/static/private').PROCESSOR_ARCHITECTURE} */
export const PROCESSOR_ARCHITECTURE = "AMD64";

/** @type {import('$env/static/private').PROCESSOR_IDENTIFIER} */
export const PROCESSOR_IDENTIFIER = "AMD64 Family 25 Model 33 Stepping 2, AuthenticAMD";

/** @type {import('$env/static/private').PROCESSOR_LEVEL} */
export const PROCESSOR_LEVEL = "25";

/** @type {import('$env/static/private').PROCESSOR_REVISION} */
export const PROCESSOR_REVISION = "2102";

/** @type {import('$env/static/private').ProgramData} */
export const ProgramData = "C:\\ProgramData";

/** @type {import('$env/static/private').ProgramFiles} */
export const ProgramFiles = "C:\\Program Files";

/** @type {import('$env/static/private').ProgramW6432} */
export const ProgramW6432 = "C:\\Program Files";

/** @type {import('$env/static/private').PROMPT} */
export const PROMPT = "$P$G";

/** @type {import('$env/static/private').PSModulePath} */
export const PSModulePath = "C:\\Users\\lucas\\Documents\\WindowsPowerShell\\Modules;C:\\Program Files\\WindowsPowerShell\\Modules;C:\\windows\\system32\\WindowsPowerShell\\v1.0\\Modules";

/** @type {import('$env/static/private').PUBLIC} */
export const PUBLIC = "C:\\Users\\Public";

/** @type {import('$env/static/private').SESSIONNAME} */
export const SESSIONNAME = "Console";

/** @type {import('$env/static/private').SystemDrive} */
export const SystemDrive = "C:";

/** @type {import('$env/static/private').SystemRoot} */
export const SystemRoot = "C:\\windows";

/** @type {import('$env/static/private').TEMP} */
export const TEMP = "C:\\Users\\lucas\\AppData\\Local\\Temp";

/** @type {import('$env/static/private').TERM_PROGRAM} */
export const TERM_PROGRAM = "vscode";

/** @type {import('$env/static/private').TERM_PROGRAM_VERSION} */
export const TERM_PROGRAM_VERSION = "1.70.0";

/** @type {import('$env/static/private').TMP} */
export const TMP = "C:\\Users\\lucas\\AppData\\Local\\Temp";

/** @type {import('$env/static/private').USERDOMAIN} */
export const USERDOMAIN = "LUCASST";

/** @type {import('$env/static/private').USERDOMAIN_ROAMINGPROFILE} */
export const USERDOMAIN_ROAMINGPROFILE = "LUCASST";

/** @type {import('$env/static/private').USERNAME} */
export const USERNAME = "lucas";

/** @type {import('$env/static/private').USERPROFILE} */
export const USERPROFILE = "C:\\Users\\lucas";

/** @type {import('$env/static/private').VSCODE_GIT_ASKPASS_EXTRA_ARGS} */
export const VSCODE_GIT_ASKPASS_EXTRA_ARGS = "--ms-enable-electron-run-as-node";

/** @type {import('$env/static/private').VSCODE_GIT_ASKPASS_MAIN} */
export const VSCODE_GIT_ASKPASS_MAIN = "c:\\Users\\lucas\\AppData\\Local\\Programs\\Microsoft VS Code\\resources\\app\\extensions\\git\\dist\\askpass-main.js";

/** @type {import('$env/static/private').VSCODE_GIT_ASKPASS_NODE} */
export const VSCODE_GIT_ASKPASS_NODE = "C:\\Users\\lucas\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe";

/** @type {import('$env/static/private').VSCODE_GIT_IPC_HANDLE} */
export const VSCODE_GIT_IPC_HANDLE = "\\\\.\\pipe\\vscode-git-3bd63aa6df-sock";

/** @type {import('$env/static/private').windir} */
export const windir = "C:\\windows";