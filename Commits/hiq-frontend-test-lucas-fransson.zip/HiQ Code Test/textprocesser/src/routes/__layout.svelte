<script>
	import Header from '$lib/header/Header.svelte';
	import Footer from '../lib/footer/Footer.svelte';
	import '../app.css';
</script>

<Header />

<main class="flex flex-1 flex-col p-4 w-full max-w-5xl m-auto box-border">
	<slot />
</main>

<Footer />