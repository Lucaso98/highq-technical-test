<header class="flex flex-col content-center items-center p-10 bg-emerald-600">
	<p class="text-2xl text-white">Textprocesser</p>
</header>