1. How much time did you end up spending on this coding test?

    - I spent around 6-8 hours on this test.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

2. Explain why you chose the code structure(s) you used in your solution.

    - I chose to build this application with Javascript and Svelte. Svelte is a framework that compiles all code into vanilla Javascript code, making it easier for webbrowsers to read the code, resulting in faster websites. It is also the framework I'm most comfortable with and it's pretty fast and easy to set up. 
    
    - While the project structure might look a bit messy, it's actually pretty logical since you use components and routes and as long as you use descriptive names for the components and folders, it won't get messy. 
    
    - For the code structure I used Svelte, where you mix Javascript and Svelte code with HTML and you write the Javascript code in the same file. I think this is cleaner since you know that all the Javascript code written is only relevant for the file it's in, as opposed to writing it in a seperate file and link it in.

    - I also added Tailwind, a CSS framework, for the styles. I did this mostly because it's easier and faster and I think it looks cleaner if you write good Tailwind code instead of regular CSS.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

3. What would you add to your solution if you had more time? This question is especially important if you did not spend much time on the coding test - use this as an opportunity to explain what your solution is missing.

- I would probably try to make it shorter and cleaner. It works as intended now but you can always find a simpler, cleaner, more readable solution!

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4. What did you think of this recruitment test?

- I liked it! It was simple enough but still a bit challenging. There were multiple solutions to this test and I struggled the most with finding and choosing one I liked and could understand and explain good enough.